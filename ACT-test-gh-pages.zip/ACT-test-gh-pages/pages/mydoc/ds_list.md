---
title: Data Steward Listserv
keywords: data steward, list, listserv, email
sidebar: mydoc_sidebar
permalink: ds_list.html
folder: mydoc
---
## Joining the Listserv
To join the ACTfacilitatorsDS@list.pitt.edu mailing list, please click [here](https://list.pitt.edu/mailman/listinfo/ACTfacilitatorsDS) and enter your email address in order to make a request. After submission, you will receive an email confirmation. Once approved by the list moderator, you will receive a notification of your acceptance. 

## New ACT Member?
If you are a new data steward, please also send an email to Paige Ottmar at <pottmar@chartis.com> to be added to the master ACT contact list.

## Searching the Listserv
An archive of the mailing list can be found [here](https://list.pitt.edu/mailman/private/actfacilitatorsds/). Please note that the archive is only accessible for current list subscribers.


{% include links.html %}
