---
title: Technology Listserv
permalink: tech_list.html
keywords: technology, listserv, list, email
sidebar: mydoc_sidebar
folder: mydoc
---

## Joining the Listserv
To join the ACTtecdh@list.pitt.edu mailing list, please go [here](https://list.pitt.edu/mailman/listinfo/ACTtecdh) and enter your email address to complete the request. You will then receive a confirmation email before your request is sent to the list moderator. Once your request is approved, you will receive a notification.

## New ACT Member?
If you are a new ACT member for your site, please send an email to Paige Ottmar at <pottmar@chartis.com> to be added to the master ACT contact list.

## Searching the Listserv
An archive of the mailing list can be found [here](https://list.pitt.edu/mailman/private/acttecdh/). Please note that the archive is only accessible for current list subscribers.

{% include links.html %}
