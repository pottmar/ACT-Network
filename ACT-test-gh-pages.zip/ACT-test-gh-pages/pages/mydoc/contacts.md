---
title: Key Contacts
keywords: contacts, email, contact
summary: "Below are the key personnel for the various aspects of the ACT Network. "
sidebar: mydoc_sidebar
permalink: contacts.html
folder: mydoc
---

* **National Project Manager:** Elaina Sendro, <esendro@chartis.com>

* **i2b2:** Nich Wattanasin, <nwattanasin@mgh.harvard.edu>

* **SHRINE:** Simon Chang, <simon_chang@hms.harvard.edu>

* **Ontology:** Michele Morris, <mim18@pitt.edu>

* **Dissemination:**: Lindsay Lennox, <lindsay.lennox@cuanschutz.edu>

* **JIRA:** Paige Ottmar, <pottmar@chartis.com>

{% include links.html %}

