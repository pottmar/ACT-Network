git add .
git status
git commit -m "content update"
git push