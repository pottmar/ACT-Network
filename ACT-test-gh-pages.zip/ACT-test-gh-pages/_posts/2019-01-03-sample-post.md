---
title:  "Sample post"
published: true
permalink: samplepost.html
summary: "This is some summary frontmatter for my sample post."
---

This is an example of a sample post that can be shared via the knowledge sharing tab. Posts will be added as necessary with the appropriate title and keyword to allow user searching. 

{% include links.html %}
